﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GPSImageTag
{
    public static class Configuration
    {
        /// <summary>
        /// Azure Storage Connection String. UseDevelopmentStorage=true points to the storage emulator.
        /// </summary>
        public const string StorageConnectionString = "DefaultEndpointsProtocol=https;AccountName=<Azure Storage account name goes here>;AccountKey=<Azure Storage account key goes here>";
        public const string StorageContainerName = "photos";
    }
}
