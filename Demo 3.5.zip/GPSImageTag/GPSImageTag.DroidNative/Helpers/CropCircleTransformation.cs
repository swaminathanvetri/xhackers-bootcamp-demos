using Android.OS;
using Com.Squareup.Picasso;
using Android.Graphics;
using static Android.Graphics.Shader;
using System.Diagnostics;

namespace GPSImageTag.DroidNative.Helpers
{
    public class CropCircleTransformation : Java.Lang.Object, ITransformation
    {

        public Bitmap Transform(Bitmap source)
        {

            if (source == null || source.IsRecycled)
            {
                return null;
            }

            int width = source.Width;
            int height = source.Height;


            Bitmap canvasBitmap = Bitmap.CreateBitmap(width, height, Bitmap.Config.Argb8888);

            try
            {
                BitmapShader shader = new BitmapShader(source, TileMode.Clamp, TileMode.Clamp);
                Paint paint = new Paint();
                paint.AntiAlias = true;
                paint.SetShader(shader);

                Canvas canvas = new Canvas(canvasBitmap);
                float radius = width > height ? ((float)height) / 2f : ((float)width) / 2f;
                canvas.DrawCircle(width / 2, height / 2, radius, paint);

                if (canvasBitmap != source)
                {
                    source.Recycle();
                }
            }
            catch (System.Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Error occurred CropCircleTransformation: " + ex);
            }

            return canvasBitmap;
        }

        string ITransformation.Key()
        {
            return "circle()";
        }

    }

}