﻿using Android.App;
using Android.Content.PM;
using Android.OS;
using GPSImageTag.Core.Helpers;
using GPSImageTag.Core.Interfaces;
using GPSImageTag.Core.Services;
using Acr.UserDialogs;
using HockeyApp.Android;
using HockeyApp.Android.Metrics;

namespace GPSImageTag.Droid
{
    [Activity(Label = "GPSImageTag", Icon = "@drawable/icon", Theme = "@style/MainTheme", MainLauncher = true, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class MainActivity : global::Xamarin.Forms.Platform.Android.FormsAppCompatActivity
    {
        public const string HockeyAppId = "25d5fbdc3222420d81e5c2f3dda568c0";
        protected override async void OnCreate(Bundle bundle)
        {
            TabLayoutResource = Resource.Layout.Tabbar;
            ToolbarResource = Resource.Layout.Toolbar;

            base.OnCreate(bundle);
            UserDialogs.Init(this);
            RegisterServices();
            await ServiceManager.GetObject<IPhotoService>().InitCamera();
            global::Xamarin.Forms.Forms.Init(this, bundle);
            Xamarin.FormsMaps.Init(this, bundle);


            // ... your own OnCreate implementation
            CrashManager.Register(this, HockeyAppId);
            UpdateManager.Register(this, HockeyAppId);

            //// Register the MetricsManager for Logging
            MetricsManager.Register(Application,HockeyAppId);
            MetricsManager.EnableUserMetrics();

            //// Add an event to track
            MetricsManager.TrackEvent("Android Demo app started");


            LoadApplication(new App());
        }

        private void RegisterServices()
        {
            ServiceManager.Register<IDialogService>(new DialogService());
            ServiceManager.Register<IPhotoService>(new PhotoService());
            ServiceManager.Register<IAzureStorageService>(new AzureStorageService());
            ServiceManager.Register<IAzureService>(new AzureService());
            ServiceManager.Register<IGPSService>(new GPSService());
        }
    }
}

