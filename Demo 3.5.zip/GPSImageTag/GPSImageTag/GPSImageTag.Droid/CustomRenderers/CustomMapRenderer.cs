using System.ComponentModel;
using Android.Content;
using Android.Gms.Maps;
using Android.Gms.Maps.Model;
using Android.Widget;
using Xamarin.Forms;
using Xamarin.Forms.Maps;
using Xamarin.Forms.Maps.Android;
using Xamarin.Forms.Platform.Android;
using GPSImageTag.Droid.CustomRenderers;
using Com.Squareup.Picasso;
using GPSImageTag.Controls;
using Android.Graphics;
using System.Net;
using System.Collections.Generic;
using System;
using System.Linq;
using GPSImageTag.Core.Models;

[assembly: ExportRenderer(typeof(CustomMap), typeof(CustomMapRenderer))]
namespace GPSImageTag.Droid.CustomRenderers
{
    public class CustomMapRenderer : MapRenderer, GoogleMap.IInfoWindowAdapter, IOnMapReadyCallback
    {
        GoogleMap map;
        bool isDrawn;
        List<Photo> customPins;
  
        protected override void OnElementChanged(ElementChangedEventArgs<Map> e)
        {
            base.OnElementChanged(e);

            if (e.NewElement != null)
            {
                var formsMap = (CustomMap)e.NewElement;
                customPins = formsMap.CustomPins.ToList();
                ((MapView)Control).GetMapAsync(this);
            }

        }


        protected override void OnElementPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            base.OnElementPropertyChanged(sender, e);

            if (this.Element == null || this.Control == null)
                return;


            if (e.PropertyName == nameof(CustomMap.CustomPins))
            {
                var formsMap = (CustomMap)Element;
                customPins = formsMap.CustomPins.ToList();
                foreach (var pin in customPins)
                {
                    if (!string.IsNullOrWhiteSpace(pin.Latitude) && !string.IsNullOrWhiteSpace(pin.Longitude))
                    {
                        var marker = new MarkerOptions();
                        marker.SetPosition(new LatLng(double.Parse(pin.Latitude), double.Parse(pin.Longitude)));
                        marker.SetTitle(pin.Name);
                        marker.SetSnippet(pin.Description);
                        map.AddMarker(marker);
                    }
                }
            }

        }


        public void OnMapReady(GoogleMap googleMap)
        {
            map = googleMap;
            map.SetInfoWindowAdapter(this);
        }

        protected override void OnLayout(bool changed, int l, int t, int r, int b)
        {
            base.OnLayout(changed, l, t, r, b);

            if (changed)
            {
                isDrawn = false;
            }
        }


        public Android.Views.View GetInfoContents(Marker marker)
        {
            var inflater = Android.App.Application.Context.GetSystemService(Context.LayoutInflaterService) as Android.Views.LayoutInflater;
            if (inflater != null)
            {

                var customPin = GetCustomPin(marker.Title);
                if (customPin == null)
                {
                    throw new Exception("Custom pin not found");
                }


                Android.Views.View view = inflater.Inflate(GPSImageTag.Droid.Resource.Layout.MapInfoWindow, null);
                var imageview = view.FindViewById<ImageView>(GPSImageTag.Droid.Resource.Id.photoview);
                var imageBitmap = BitmapFactory.DecodeResource(Forms.Context.Resources,GPSImageTag.Droid.Resource.Drawable.androidlogo);
                var infoTitle = view.FindViewById<TextView>(Resource.Id.InfoWindowTitle);
                var infoSubtitle = view.FindViewById<TextView>(Resource.Id.InfoWindowSubtitle);
           
                if (customPin != null)
                {
                    if (!string.IsNullOrEmpty(customPin.Uri))
                    {
                        imageBitmap = GetImageBitmapFromUrl(customPin.Uri);
                        imageview.SetImageBitmap(imageBitmap);

                        if (infoTitle != null)
                        {
                            infoTitle.Text = customPin.Name;
                        }
                        if (infoSubtitle != null)
                        {
                            infoSubtitle.Text = customPin.Description;
                        }
                    }
                }

                return view;
            }
            return null;
        }

        public Android.Views.View GetInfoWindow(Marker marker)
        {
            return null;
        }

        private Bitmap GetImageBitmapFromUrl(string url)
        {
            Bitmap imageBitmap = null;

            using (var webClient = new WebClient())
            {
                var imageBytes = webClient.DownloadData(url);
                if (imageBytes != null && imageBytes.Length > 0)
                {
                    imageBitmap = BitmapFactory.DecodeByteArray(imageBytes, 0, imageBytes.Length);
                }
            }

            return imageBitmap;
        }

        Photo GetCustomPin(string pinName)
        {

            foreach (var pin in customPins)
            {
                if (pin.Name == pinName)
                {
                    return pin;
                }
            }
            return null;
        }


    }
}

