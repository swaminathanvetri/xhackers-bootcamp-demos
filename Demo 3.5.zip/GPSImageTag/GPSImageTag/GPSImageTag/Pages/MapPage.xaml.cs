﻿using GPSImageTag.Core.Models;
using GPSImageTag.ViewModels;
using System;
using System.Collections.Generic;

using Xamarin.Forms;
using Xamarin.Forms.Maps;

namespace GPSImageTag
{
    public partial class MapPage : ContentPage
    {
        PhotosPageViewModel vm;
 
        public MapPage()
        {
            InitializeComponent();

            vm = new PhotosPageViewModel();

             BindingContext = vm;

            Device.BeginInvokeOnMainThread(() =>
            {
                PhotoMap.MoveToRegion(MapSpan.FromCenterAndRadius(new Position(55.463734, -108.086924), Distance.FromMiles(1000.0)));
            });


        }

        private async void btnCurrentLocation_Clicked(object sender, EventArgs e)
        {

            await vm.GetLocation();
 
            Device.BeginInvokeOnMainThread(() =>
            {
                PhotoMap.MoveToRegion(MapSpan.FromCenterAndRadius(new Position(vm.MapCenter.Latitude, vm.MapCenter.Longitude), Distance.FromMiles(1.0)));
            });


        }
    }
}
