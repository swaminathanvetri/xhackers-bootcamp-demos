﻿using GPSImageTag.Core.Models;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Xamarin.Forms;
using Xamarin.Forms.Maps;

namespace GPSImageTag.Controls
{
    public class CustomMap: Map
    {
   
        public static readonly BindableProperty CustomPinsProperty = BindableProperty.Create(nameof(CustomPins),
                               typeof(ObservableCollection<Photo>),
                               typeof(CustomMap),
                               defaultValue:null,
                               defaultBindingMode: BindingMode.TwoWay);

        /// <summary>
        /// Gets or sets the driver pin.
        /// </summary>
        /// <value>The driver pin.</value>
        public ObservableCollection<Photo> CustomPins
        {
            get { return (ObservableCollection<Photo>)GetValue(CustomPinsProperty); }
            set { SetValue(CustomPinsProperty, value); }
        }
    }
}
