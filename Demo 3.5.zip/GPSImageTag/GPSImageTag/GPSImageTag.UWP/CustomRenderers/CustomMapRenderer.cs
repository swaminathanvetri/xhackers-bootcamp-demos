﻿using GPSImageTag.Controls;
using GPSImageTag.UWP.CustomRenderers;
using System;
using System.Collections.Generic;
using System.Linq;
using Windows.Devices.Geolocation;
using Windows.Storage.Streams;
using Windows.UI.Xaml.Controls.Maps;
using Xamarin.Forms.Maps;
using Xamarin.Forms.Maps.UWP;
using Xamarin.Forms.Platform.UWP;
using System.ComponentModel;
using GPSImageTag.UWP.Controls;
using GPSImageTag.Core.Models;

[assembly: ExportRenderer(typeof(CustomMap), typeof(CustomMapRenderer))]
namespace GPSImageTag.UWP.CustomRenderers
{
    public class CustomMapRenderer : MapRenderer
    {
        MapControl nativeMap;
        List<Photo> customPins;
        MapOverlay mapOverlay;
        bool MapOverlayShown = false;

        protected override void OnElementChanged(ElementChangedEventArgs<Map> e)
        {
            base.OnElementChanged(e);

            if (e.OldElement != null)
            {
                nativeMap.MapElementClick -= OnMapElementClick;
                nativeMap.Children.Clear();
                mapOverlay = null;
                nativeMap = null;
            }

            if (e.NewElement != null)
            {
                var formsMap = (CustomMap)e.NewElement;
                nativeMap = Control as MapControl;
                customPins = formsMap.CustomPins.ToList();
            }
        }

        protected override void OnElementPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            base.OnElementPropertyChanged(sender, e);

            if (this.Element == null || this.Control == null)
                return;


            if (e.PropertyName == nameof(CustomMap.CustomPins))
            {
                var formsMap = (CustomMap)Element;
                customPins = formsMap.CustomPins.ToList();
                UpdateMapPins();
            }
         }

        private void UpdateMapPins()
        {

            if (customPins !=null && customPins.Count > 0)
            {
                nativeMap.Children.Clear();
                nativeMap.MapElementClick += OnMapElementClick;

                foreach (var pin in customPins)
                {
                    if (!string.IsNullOrEmpty(pin.Latitude) && !string.IsNullOrEmpty(pin.Latitude))
                    {
                        var snPosition = new BasicGeoposition { Latitude = double.Parse(pin.Latitude), Longitude = double.Parse(pin.Longitude) };
                        var snPoint = new Geopoint(snPosition);

                        var mapIcon = new MapIcon();
                        mapIcon.Image = RandomAccessStreamReference.CreateFromUri(new Uri("ms-appx:///Assets/pin.png"));
                        mapIcon.CollisionBehaviorDesired = MapElementCollisionBehavior.RemainVisible;
                        mapIcon.Location = snPoint;
                        mapIcon.Title = pin.Name;
                        mapIcon.NormalizedAnchorPoint = new Windows.Foundation.Point(0.5, 1.0);
                        nativeMap.MapElements.Add(mapIcon);
                    }
                }

            }
        }

        private void OnMapElementClick(MapControl sender, MapElementClickEventArgs args)
        {

            var mapIcon = args.MapElements.FirstOrDefault(x => x is MapIcon) as MapIcon;
                                  
            if (mapIcon != null)
            {
                if (!MapOverlayShown)
                {
                    var customPin = GetCustomPin(mapIcon.Title);
                    if (customPin == null)
                    {
                        throw new Exception("Custom pin not found");
                    }

                    mapOverlay = new MapOverlay(customPin);
                    var snPosition = new BasicGeoposition { Latitude = double.Parse(customPin.Latitude), Longitude = double.Parse(customPin.Longitude) };
                    var snPoint = new Geopoint(snPosition);

                    nativeMap.Children.Add(mapOverlay);
                    MapControl.SetLocation(mapOverlay, snPoint);
                    MapControl.SetNormalizedAnchorPoint(mapOverlay, new Windows.Foundation.Point(0.5, 1.0));
                    MapOverlayShown = true;

                }
                else
                {
                    nativeMap.Children.Remove(mapOverlay);
                    MapOverlayShown = false;
                }
            }
        }

        Photo GetCustomPin(string mapIconName)
        {
  
            foreach (var pin in customPins)
            {
                if (pin.Name == mapIconName)
                {
                    return pin;
                }
            }
            return null;
        }
    }

}

