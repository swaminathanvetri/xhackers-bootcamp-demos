﻿using GPSImageTag.Controls;
using GPSImageTag.Core.Models;
using System;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media.Imaging;

// The User Control item template is documented at http://go.microsoft.com/fwlink/?LinkId=234236

namespace GPSImageTag.UWP.Controls
{
    public sealed partial class MapOverlay : UserControl
    {
        Photo customPin;
        public MapOverlay(Photo pin)
        {
            this.InitializeComponent();
            customPin = pin;
            SetupData();
        }

        void SetupData()
        {
            if (customPin != null)
            {
                if (!string.IsNullOrEmpty(customPin.Uri))
                {
                    photo.Source = new BitmapImage(new Uri(customPin.Uri));
                    photoname.Text = customPin.Name;
                    photodesc.Text = customPin.Description;
                }
            }
        }
    }
}
