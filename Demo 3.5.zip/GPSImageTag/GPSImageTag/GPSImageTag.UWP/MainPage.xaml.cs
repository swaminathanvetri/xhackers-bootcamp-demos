﻿using Microsoft.HockeyApp;

namespace GPSImageTag.UWP
{
    public sealed partial class MainPage
    {
        public MainPage()
        {
            this.InitializeComponent();
            Xamarin.FormsMaps.Init("INSERT_MAP_KEY_HERE");
             
            HockeyClient.Current.TrackEvent("UWP Demo app started");

            LoadApplication(new GPSImageTag.App());
        }

    }
}
