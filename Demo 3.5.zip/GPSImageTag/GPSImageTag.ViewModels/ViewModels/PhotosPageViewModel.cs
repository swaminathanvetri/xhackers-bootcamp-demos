﻿using GPSImageTag.Core.Helpers;
using GPSImageTag.Core.Interfaces;
using GPSImageTag.Core.Models;
using GPSImageTag.Core.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Threading.Tasks;

namespace GPSImageTag.ViewModels
{
    public class PhotosPageViewModel : BaseViewModel
    {
        private IAzureService mobileService;
        private IGPSService gpsService;
        private IDialogService dialogService;
        private ObservableCollection<Photo> photos;
        private MapLocation mapCenter;

        public ObservableCollection<Photo> Photos
        {
            get { return photos; }
            set
            {
                photos = value; OnPropertyChanged("Photos");
            }
        }

        public Command GetPhotosCommand { get; set; }
   
        public PhotosPageViewModel()
        {
            Title = "Photo List";
            photos = new ObservableCollection<Photo>();
            GetPhotosCommand = new Command(
                async () => await GetPhotos(),
                () => !IsBusy);

            dialogService = ServiceManager.GetObject<IDialogService>();
            mobileService = ServiceManager.GetObject<IAzureService>();
            gpsService = ServiceManager.GetObject<IGPSService>();
        }

        public MapLocation MapCenter
        {
            get
            {
                return mapCenter;
            }
  
        }

        public async Task GetLocation()
        {
            if (IsBusy)
                return;

            List<Photo> photos = new List<Photo>();

            try
            {

                IsBusy = true;
                mapCenter = await gpsService.GetCurrentLocation();
      
                var item = new Photo
                {
                    Latitude = mapCenter.Latitude.ToString(),
                    Longitude = mapCenter.Longitude.ToString(),
                    Name = "Current Location"
                };

                photos.Add(item);

                Photos = new ObservableCollection<Photo>(photos);
                OnPropertyChanged("Photos");

            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error: " + ex);
                dialogService.ShowError("Error! " + ex.Message + " OK");
            }
            finally
            {
                IsBusy = false;
            }

        }

        public async Task GetPhotos()
        {
            if (IsBusy)
                return;
            List<Photo> photos = new List<Photo>();

            try
            {

                IsBusy = true;
                var items = await mobileService.GetPhotos();
      
                foreach (var item in items)
                     photos.Add(item);

                Photos = new ObservableCollection<Photo>(photos);
                OnPropertyChanged("Photos");
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error: " + ex);
                dialogService.ShowError("Error! " + ex.Message + " OK");
            }
            finally
            {
                IsBusy = false;
            }

        }
    }
}
