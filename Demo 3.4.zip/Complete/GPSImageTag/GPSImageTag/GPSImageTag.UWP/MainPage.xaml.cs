﻿using Microsoft.HockeyApp;

namespace GPSImageTag.UWP
{
    public sealed partial class MainPage
    {
        public MainPage()
        {
            this.InitializeComponent();
            
            HockeyClient.Current.TrackEvent("UWP Demo app started");

            LoadApplication(new GPSImageTag.App());
        }
    }
}
