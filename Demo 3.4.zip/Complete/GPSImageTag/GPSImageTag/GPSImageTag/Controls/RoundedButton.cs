﻿using Xamarin.Forms;

namespace GPSImageTag.Controls
{
    public class RoundedButton: Button
    {
    }
}
