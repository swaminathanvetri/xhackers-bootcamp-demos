﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;

namespace GPSImageTag.Controls
{
    public partial class CameraUploadView : ContentView
    {
        public CameraUploadView()
        {
            InitializeComponent();
        }
    }
}
