﻿namespace GPSImageTag.Core.Models
{
    public class MapLocation
    {

        public double Latitude { get; set; }

        public double Longitude { get; set; }


    }
}
