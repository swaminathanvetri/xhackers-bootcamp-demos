#r "System.Drawing"

using System.Drawing;
using System.Drawing.Imaging;
using System.Net;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;

public static async Task<HttpResponseMessage> Run(HttpRequestMessage req, Stream imageStream, TraceWriter log)
{
    log.Info("C# HTTP trigger function processed a request.");

    log.Info($"C# Blob trigger function Processed blob\n Size: {imageStream.Length} Bytes");

    var outputStream = new MemoryStream();
    Image image = Image.FromStream(imageStream);
    Image thumb = image.GetThumbnailImage(120, 120, ()=>false, IntPtr.Zero);

    thumb.Save(outputStream,ImageFormat.Png);
    outputStream.Position = 0;
    var response = req.CreateResponse();
    response.Content = new StreamContent(outputStream);
    response.Content.Headers.ContentLength = outputStream.Length;
    response.Content.Headers.ContentType = 
        new MediaTypeHeaderValue("image/png");

    return response;
}