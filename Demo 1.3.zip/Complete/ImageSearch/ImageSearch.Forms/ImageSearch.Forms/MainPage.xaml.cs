﻿using ImageSearch.ViewModel;
using System;

using Xamarin.Forms;

namespace ImageSearch.Forms
{
    public partial class MainPage: ContentPage
    {
        ImageSearchViewModel viewModel;
        public MainPage()
        {
            InitializeComponent();
            viewModel = new ImageSearchViewModel();
        }

        private async void MyButton_Clicked(object sender, EventArgs e)
        {
            MyButton.IsEnabled = false;
            // Before long running Task (activate and show indicator)
            Indicator.IsRunning = true;
            Indicator.IsVisible = true;


            await viewModel.SearchForImagesAsync(MyQuery.Text.Trim());
            ListView.ItemsSource = viewModel.Images;

            // After long running Task (deactivate and hide indicator)
            Indicator.IsRunning = false;
            Indicator.IsVisible = false;
            MyButton.IsEnabled = true;

        }
    }
}
